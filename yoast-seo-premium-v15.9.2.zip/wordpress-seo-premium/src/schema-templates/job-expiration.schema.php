<?php // phpcs:ignore Internal.NoCodeFound ?>
{{schema name="yoast/job-expiration" only-nested=true}}
{{attribute name="expirationDate"}}
