<?php // phpcs:ignore Internal.NoCodeFound ?>
{{schema name="yoast/job-description" only-nested=true}}
{
	"name": {{html name="description"}}
}
